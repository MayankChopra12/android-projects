package com.example.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button signupButton;
    EditText username,password,fullname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        signupButton=findViewById(R.id.signup);
        username=findViewById(R.id.username);
        fullname=findViewById(R.id.fullname);
        password=findViewById(R.id.password);

        final String fullName=fullname.getText().toString().trim();
        final String userName=username.getText().toString().trim();
        final String passWord=password.getText().toString().trim();

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fullName.equals("") || userName.equals("") || passWord.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "oops enter some data", Toast.LENGTH_LONG).show();
                }else if(passWord.length()>8)
                {
                    Toast.makeText(getApplicationContext(),"password length >8",Toast.LENGTH_LONG).show();



                } else{
                    Toast.makeText(getApplicationContext(),"Sucess", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this,mainactivity_2.class);
                    intent.putExtra(" name",fullName);
                    intent.putExtra(" username",userName);
                    intent.putExtra("password",passWord );
                    startActivity(intent);


                }

            }
        });


    }
}
