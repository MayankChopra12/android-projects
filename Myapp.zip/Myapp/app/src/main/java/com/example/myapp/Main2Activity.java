package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;

import java.net.URL;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        handlingIntent();
    }

    private void handlingIntent() {
        Intent intent= new Intent();
        Uri data = intent.getData();
        URL url= null;
        try {
            url = new URL(data.getScheme(), data.getHost() ,data.getPath());


        } catch (Exception e){
            e.printStackTrace();
            WebView webView= findViewById(R.id.webview);
            webView.loadUrl(url.toString());

        }

    }
}
