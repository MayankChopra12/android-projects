package com.example.spinner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
    Context context;
    int flags[];
    String[] countryNames;
    LayoutInflater inflater;

    public CustomAdapter(Context context, int[] flags, String[] countryNames ) {
        this.context = context;
        this.flags = flags;
        this.countryNames = countryNames;
        inflater=(LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return flags.length;
    }

    @Override
    public Object getItem(int i) { // i is poistion//
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.custom,null);
        ImageView icon =(ImageView)view.findViewById(R.id.imageview);
        TextView names =(TextView) view .findViewById(R.id.textview);
        icon.setImageResource(flags[i]);
        names.setText(countryNames[i]);
        return view;
    }
}
