package com.example.countries;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerCountry,spinnerState,spinnerCity;
    ArrayList<State> tempState =new ArrayList<>();
    ArrayList<City> tempCity = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinnerCountry=findViewById(R.id.country);
        spinnerState=findViewById(R.id.state);
        spinnerCity=findViewById(R.id.city);

        final List <Country> countries= new ArrayList<>();
        countries.add(new Country(" 1","select your country "));
        countries.add(new Country(" 2","india "));
        countries.add(new Country(" 3","uk"));
        countries.add(new Country(" 4","uk"));
        ArrayAdapter<Country> countryArrayAdapter =new ArrayAdapter<Country>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,countries);
        spinnerCountry.setAdapter(countryArrayAdapter);

        final List <State> states = new ArrayList<>();
        states.add(new State("1","select your state","1"));
        states.add(new State("2","Gujarat","2"));
        states.add(new State("3","Mahashatra","3"));
        states.add(new State("4","New york","4"));
        states.add(new State("5","new jersey","5"));
        states.add(new State("6","tamania","6"));
        states.add(new State("7","victoria","7"));
        final List <City>   cities =new ArrayList<>();
        cities.add(new City("1","select your city","1"));

        cities.add(new City("2","delhi","2"));

        cities.add(new City("3"," Ahmedabad","2"));

        cities.add(new City("4","Mumbai","3"));

        cities.add(new City("5","Mobpart","3"));
        cities.add(new City("6","Mobpart","4"));
        cities.add(new City("7","Mobpart","4"));
        cities.add(new City("8","Mobpart","5"));
        cities.add(new City("9","Mobpart","5"));
        cities.add(new City("10","Mobpart","6"));
        cities.add(new City("11","Mobpart","6"));
        cities.add(new City("12","Mobpart","7"));
        cities.add(new City("13","Mobpart","7"));



        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempState.clear();
                for(int s=0; s<states.size();s++)
                {
                    if(states.get(s).getCountry_fk().equals(countries.get(i).getCountry_id()))
                    { tempState.add(states.get(s));

                    }
                }
                ArrayAdapter<State> stateArrayAdapter =new ArrayAdapter<State>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,tempState);
                spinnerState.setAdapter(stateArrayAdapter);
                tempCity.clear();
                for(int c=0; c< cities.size();c++)
                {
                    if(tempState.get(spinnerState.getSelectedItemPosition()).getState_id().equals(cities.get(c).getStae_fk())){
                        tempCity.add(cities.get(c));

                    }
                }
                ArrayAdapter<City> adapter3 = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_dropdown_item_1line);

                spinnerCity.setAdapter(adapter3);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });








    }

   public class  Country{
        String country_id ;
        String country_name ;

       public Country(String country_id, String country_name) {
           this.country_id = country_id;
           this.country_name = country_name;
       }

       public String getCountry_id() {
           return country_id;
       }

       public void setCountry_id(String country_id) {
           this.country_id = country_id;
       }

       public String getCountry_name() {
           return country_name;
       }

       public void setCountry_name(String country_name) {
           this.country_name = country_name;
       }

       @Override
       public String toString() {
           return country_name;
       }
   }
   public class State{
        String state_name;
        String state_id;
        String country_fk;

       public State(String state_name, String state_id, String country_fk) {
           this.state_name = state_name;
           this.state_id = state_id;
           this.country_fk = country_fk;
       }

       public String getState_name() {
           return state_name;
       }

       public void setState_name(String state_name) {
           this.state_name = state_name;
       }

       public String getState_id() {
           return state_id;
       }

       public void setState_id(String state_id) {
           this.state_id = state_id;
       }

       public String getCountry_fk() {
           return country_fk;
       }

       public void setCountry_fk(String country_fk) {
           this.country_fk = country_fk;
       }

       @Override
       public String toString() {
           return state_name;
       }
   }

   public class City{
        String city_name;
        String city_id;
        String stae_fk;

       public City(String city_name, String city_id, String stae_fk) {
           this.city_name = city_name;
           this.city_id = city_id;
           this.stae_fk = stae_fk;
       }

       public String getCity_name() {
           return city_name;
       }

       public void setCity_name(String city_name) {
           this.city_name = city_name;
       }

       public String getCity_id() {
           return city_id;
       }

       public void setCity_id(String city_id) {
           this.city_id = city_id;
       }

       public String getStae_fk() {
           return stae_fk;
       }

       public void setStae_fk(String stae_fk) {
           this.stae_fk = stae_fk;
       }

       @Override
       public String toString() {
           return city_name;
       }
   }


}
